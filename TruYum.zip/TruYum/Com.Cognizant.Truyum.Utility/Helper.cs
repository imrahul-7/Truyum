﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Data;


namespace Com.Cognizant.Truyum.Utility
{
    public  class Helper
    {
        public string connectionString = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString;
    }
}
