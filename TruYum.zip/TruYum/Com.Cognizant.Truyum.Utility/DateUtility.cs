﻿using System;

namespace Com.Cognizant.Truyum.Utility
{
    public class DateUtility
    {
        public static DateTime ConvertToShortDateString(string inputDate)
        {
            return Convert.ToDateTime(DateTime.Parse(inputDate).ToShortDateString());
        }
    }
}
