﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Com.Cognizant.Truyum.Model
{
    public class Cart
    {
        public List<MenuItem> MenuItemList { get; set; }
        public double Total { get; set; }
    }

}
