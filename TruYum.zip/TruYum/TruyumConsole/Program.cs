﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Com.Cognizant.Truyum.Dao;
using Com.Cognizant.Truyum.Model;
using Com.Cognizant.Truyum.Utility;
//using TruyumOnline;


namespace TruyumConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice = -1;

            while (true)

            {

                Console.WriteLine("\n\n");



                Console.WriteLine("1. Get menu items list admin");

                Console.WriteLine("2.Get menu items list customer");

                Console.WriteLine("3. Get Menu Item");

                Console.WriteLine("4. Modify Menu Item");

                Console.WriteLine("5. Add Item to Cart");

                Console.WriteLine("6. Get Cart Items");

                Console.WriteLine("7. Remove Cart Item");

                Console.WriteLine("8. Exit");
                Console.WriteLine("\nEnter your choice: ");

                choice = int.Parse(Console.ReadLine());



                switch (choice)

                {

                    case 1: GetMenuItemsAdmin(); break;

                    case 2: GetMenuItemsCustomer(); break;

                    case 3: GetMenuItem(); break;

                    case 4: ModifyMenuItem(); break;

                    case 5: AddCartItem(); break;

                    case 6: GetCartItems(); break;

                    case 7: RemoveCartItems(); break;

                    case 8: Environment.Exit(0); break;

                    default: Console.WriteLine("Invalid choice"); break;

                }

            }

        }

        private static void GetMenuItemsAdmin()
        {
            List<MenuItem> menuItems = new List<MenuItem>();
            var objMenuItem = new MenuItemDaoSql();
            menuItems = objMenuItem.GetMenuItemListAdmin();
            foreach (var items in menuItems)
            {
                Console.WriteLine("Name = {0}", items.Name);
            }
        }

        private static void GetMenuItemsCustomer()
        {
            List<MenuItem> menuItems = new List<MenuItem>();
            var objMenuItem = new MenuItemDaoSql();
            menuItems = objMenuItem.GetMenuItemListCustomer();
            foreach (var items in menuItems)
            {
                Console.WriteLine("Name = {0}", items.Name);
            }
        }

        private static void GetMenuItem()
        {
            var objMenuItem = new MenuItemDaoSql();
            MenuItem menuItem = new MenuItem();
            Console.WriteLine("Enter id to retrieve");
            string id = Console.ReadLine();
            long id1 = Convert.ToInt64(id);

            menuItem = objMenuItem.GetMenuItem(id1);
            Console.WriteLine("Name={0} Price={1}", menuItem.Name, menuItem.Price);

        }

        private static void ModifyMenuItem()
        {
            var objMenuItem = new MenuItemDaoSql();
            MenuItem menuItem = new MenuItem();
            Console.WriteLine("Enter id");
            menuItem.Id = Convert.ToInt64(Console.ReadLine());
            Console.WriteLine("Enter name");
            menuItem.Name = Console.ReadLine();
            Console.WriteLine("Enter category");
            menuItem.Category = Console.ReadLine();
            Console.WriteLine("Enter price");
            menuItem.Price = Convert.ToDecimal(Console.ReadLine());
            Console.WriteLine("Enter ative(true/false)");
            menuItem.Active = Convert.ToBoolean(Console.ReadLine());
            Console.WriteLine("Enter the Date(mm/dd/yyyy");
            menuItem.DateOfLaunch = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Enter free delivery(true/false)");
            menuItem.FreeDelivery = Convert.ToBoolean(Console.ReadLine());
            objMenuItem.ModifyMenuItem(menuItem);
            Console.WriteLine("Updated");
        }

        private static void AddCartItem()
        {
            var objCartItem = new CartDaoSql();
            Console.WriteLine("Enter userId");
            string userid1 = Console.ReadLine();
            long userId = Convert.ToInt64(userid1);
            Console.WriteLine("Enter menuItemId");
            string menuItemId1 = Console.ReadLine();
            long menuItemId = Convert.ToInt64(menuItemId1);
            objCartItem.AddCartItem(userId, menuItemId);
            Console.WriteLine("Item Added");
        }

        private static void RemoveCartItems()
        {
            var objCartItem = new CartDaoSql();
            Console.WriteLine("Enter userId");
            string userid1 = Console.ReadLine();
            long userId = Convert.ToInt64(userid1);
            Console.WriteLine("Enter menuItemId");
            string menuItemId1 = Console.ReadLine();
            long menuItemId = Convert.ToInt64(menuItemId1);
            objCartItem.RemoveCartItem(userId, menuItemId);
            Console.WriteLine("Item Removed");
        }

        private static void GetCartItems()
        {
            List<MenuItem> cartItems = new List<MenuItem>();
            var objCartItem = new CartDaoSql();
            Console.WriteLine("Enter userId");
            string userid1 = Console.ReadLine();
            long userId = Convert.ToInt64(userid1);
            cartItems = objCartItem.GetAllCartItems(userId);
            if (cartItems != null && cartItems.Count > 0)
            {
                foreach (var item in cartItems)
                {
                    Console.WriteLine("Name={0},Price={1}", item.Name, item.Price);
                }
                Console.WriteLine("Total Price of items in the cart of user {0} is {1}", userId, cartItems.Sum(s => s.Price));

            }
            else
            {
                try
                {
                    throw new CartEmptyException();
                }
                catch (CartEmptyException ce)
                {
                    Console.WriteLine(ce.Message);
                }
            }
        }


    }
}

