﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using Com.Cognizant.Truyum.Model;
using Com.Cognizant.Truyum.Utility;

namespace Com.Cognizant.Truyum.Dao
{
    public class CartDaoSql : ICartDao
    {
        string sqlQuery = string.Empty;
        public void AddCartItem(long userId, long menuItemId)
        {


            using (SqlConnection sqlConnection = ConnectionHandler.GetConnection())
            {
                sqlConnection.Open();
                int res = 0;
                string sqlQuery1 = @"select 1 from cart where menuItemId=" + menuItemId.ToString() + " and userId=" + userId.ToString();
                using (SqlCommand cmd = new SqlCommand(sqlQuery1, sqlConnection))
                {

                    res = Convert.ToInt32(cmd.ExecuteScalar());

                }
                sqlQuery = @"insert into cart (menuItemID,userId)" + " values(" + menuItemId.ToString() + "," + userId.ToString() + ")";
                using (SqlCommand cmd = new SqlCommand(sqlQuery, sqlConnection))
                {

                    if (res == 0)
                    {
                        cmd.ExecuteNonQuery();
                    }

                }
            }

        }

        public List<MenuItem> GetAllCartItems(long userId)
        {
            List<MenuItem> menuItemList = new List<MenuItem>();
            MenuItem menuItem;
            sqlQuery = @"select m.* from cart as c  inner join menuItem as m on m.id=c.menuItemID where c.userId=" + userId.ToString();
            using (SqlConnection sqlConnection = ConnectionHandler.GetConnection())
            {
                sqlConnection.Open();
                var command = new SqlCommand(sqlQuery, sqlConnection);
                SqlDataReader dr = command.ExecuteReader();

                if (dr != null && dr.HasRows)
                {
                    while (dr.Read())
                    {
                        menuItem = new MenuItem();
                        menuItem.Active = Convert.ToBoolean(dr["active"]);
                        menuItem.Category = Convert.ToString(dr["category"]);
                        menuItem.Id = Convert.ToInt64(dr["id"]);
                        //  menuItem.name = Convert.ToString(dr["name"]);
                        menuItem.Name = dr.GetString(1);
                        menuItem.Price = Convert.ToDecimal(dr["price"]);
                        menuItem.DateOfLaunch = DateUtility.ConvertToShortDateString(Convert.ToString(dr["dateOfLaunch"]));
                        menuItem.FreeDelivery = Convert.ToBoolean(dr["freeDelivery"]);
                        menuItemList.Add(menuItem);
                    }
                    dr.Close();
                }
            }

            return menuItemList;
        }

        public void RemoveCartItem(long userId, long menuItemId)
        {
            using (SqlConnection sqlConnection = ConnectionHandler.GetConnection())
            {
                sqlConnection.Open();
                sqlQuery = @"delete from cart where menuItemId=" + menuItemId.ToString() + " and userId=" + userId.ToString();
                using (SqlCommand cmd = new SqlCommand(sqlQuery, sqlConnection))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
