﻿using System;
using System.Collections.Generic;
using Com.Cognizant.Truyum.Model;
using System.Data;
using System.Data.SqlClient;
using Com.Cognizant.Truyum.Utility;
using System.Configuration;


namespace Com.Cognizant.Truyum.Dao
{
    public class MenuItemDaoSql : IMenuItemDao
    {
        string sqlQuery = string.Empty;
        public MenuItem GetMenuItem(long menuItemId)
        {
            MenuItem menuItem = new MenuItem();
            sqlQuery = "select * from MenuItem where id=" + menuItemId.ToString();
            using (SqlConnection sqlConnection = ConnectionHandler.GetConnection())
            {
                sqlConnection.Open();
                var command = new SqlCommand(sqlQuery, sqlConnection);
                SqlDataReader dr = command.ExecuteReader();

                if (dr != null && dr.HasRows)
                {
                    while (dr.Read())
                    {
                        menuItem.Active = Convert.ToBoolean(dr["active"]);
                        menuItem.Category = Convert.ToString(dr["category"]);
                        menuItem.Id = Convert.ToInt64(dr["id"]);
                        //  menuItem.name = Convert.ToString(dr["name"]);
                        menuItem.Name = dr.GetString(1);
                        menuItem.Price = Convert.ToDecimal(dr["price"]);
                        menuItem.DateOfLaunch = Convert.ToDateTime(dr["dateOfLaunch"]);
                        menuItem.FreeDelivery = Convert.ToBoolean(dr["freeDelivery"]);
                    }
                    dr.Close();
                }
            }
            return menuItem;
        }

        public List<MenuItem> GetMenuItemListAdmin()
        {
            List<MenuItem> menuItemList = new List<MenuItem>();
            MenuItem menuItem;
            sqlQuery = "select * from MenuItem";
            using (SqlConnection sqlConnection = ConnectionHandler.GetConnection())
            {
                sqlConnection.Open();
                var command = new SqlCommand(sqlQuery, sqlConnection);
                SqlDataReader dr = command.ExecuteReader();

                if (dr != null && dr.HasRows)
                {
                    while (dr.Read())
                    {
                        menuItem = new MenuItem();
                        menuItem.Active = Convert.ToBoolean(dr["active"]);
                        menuItem.Category = Convert.ToString(dr["category"]);
                        menuItem.Id = Convert.ToInt64(dr["id"]);
                        //  menuItem.name = Convert.ToString(dr["name"]);
                        menuItem.Name = dr.GetString(1);
                        menuItem.Price = Convert.ToDecimal(dr["price"]);
                        menuItem.DateOfLaunch = Convert.ToDateTime(dr["dateOfLaunch"]);
                        menuItem.FreeDelivery = Convert.ToBoolean(dr["freeDelivery"]);
                        menuItemList.Add(menuItem);
                    }
                    dr.Close();
                }
            }

            return menuItemList;
            // throw new NotImplementedException();
        }

        public List<MenuItem> GetMenuItemListCustomer()
        {
            // throw new NotImplementedException();
            List<MenuItem> menuItemList = new List<MenuItem>();
            MenuItem menuItem;
            sqlQuery = "select * from MenuItem where active=1 and dateOfLaunch<GETDATE()";
            using (SqlConnection sqlConnection = ConnectionHandler.GetConnection())
            {
                sqlConnection.Open();
                var command = new SqlCommand(sqlQuery, sqlConnection);
                SqlDataReader dr = command.ExecuteReader();

                if (dr != null && dr.HasRows)
                {
                    while (dr.Read())
                    {
                        menuItem = new MenuItem();
                        menuItem.Active = Convert.ToBoolean(dr["active"]);
                        menuItem.Category = Convert.ToString(dr["category"]);
                        menuItem.Id = Convert.ToInt64(dr["id"]);
                        //  menuItem.name = Convert.ToString(dr["name"]);
                        menuItem.Name = dr.GetString(1);
                        menuItem.Price = Convert.ToDecimal(dr["price"]);
                        menuItem.DateOfLaunch = DateUtility.ConvertToShortDateString(Convert.ToString(dr["dateOfLaunch"]));
                        menuItem.FreeDelivery = Convert.ToBoolean(dr["freeDelivery"]);
                        menuItemList.Add(menuItem);
                    }
                    dr.Close();
                }
            }

            return menuItemList;
        }

        public void ModifyMenuItem(MenuItem menuItem)
        {
            MenuItem objMenuItem = GetMenuItem(menuItem.Id);
            if (objMenuItem != null)
            {
                objMenuItem.Name = menuItem.Name;
                objMenuItem.Category = menuItem.Category;
                objMenuItem.Active = menuItem.Active;
                objMenuItem.DateOfLaunch = menuItem.DateOfLaunch;
                objMenuItem.Price = menuItem.Price;
                objMenuItem.FreeDelivery = menuItem.FreeDelivery;

                sqlQuery = String.Format(@"update MenuItem set name='{0}', category='{1}', active={2}, dateOfLaunch='{3}', price={4}, freeDelivery={5} where id={6}",
                    objMenuItem.Name, objMenuItem.Category, (objMenuItem.Active) ? 1 : 0, objMenuItem.DateOfLaunch, objMenuItem.Price, (objMenuItem.FreeDelivery) ? 1 : 0, objMenuItem.Id);
                using (SqlConnection sqlConnection = ConnectionHandler.GetConnection())
                {
                    sqlConnection.Open();
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, sqlConnection))
                    {
                        cmd.ExecuteNonQuery();
                    }
                }


            }
        }
    }
}
