﻿using System;
using System.Collections.Generic;
using System.Text;
using Com.Cognizant.Truyum.Dao;
using Com.Cognizant.Truyum.Model;

namespace TruyumOnline
{
    public class CartDaoCollection : ICartDao
    {
        CartDaoSql objCart = new CartDaoSql();
        public void AddCartItem(long userId, long menuItemId)
        {
            objCart.AddCartItem(userId, menuItemId);
        }

        public List<MenuItem> GetAllCartItems(long userId)
        {
            //return  objCart.GetAllCartItems(userId);
            throw new NotImplementedException();
        }

        public void RemoveCartItem(long userId, long productId)
        {
            objCart.RemoveCartItem(userId, productId);
        }
    }
}
