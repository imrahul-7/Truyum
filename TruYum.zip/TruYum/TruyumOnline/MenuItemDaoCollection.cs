﻿using System;
using System.Collections.Generic;
using System.Text;
using Com.Cognizant.Truyum.Dao;
using Com.Cognizant.Truyum.Model;

namespace TruyumOnline
{
    public class MenuItemDaoCollection : IMenuItemDao
    {
        MenuItemDaoSql objMenuItem = new MenuItemDaoSql();
        public MenuItem GetMenuItem(long menuItemId)
        {


            return objMenuItem.GetMenuItem(menuItemId);

        }

        public List<MenuItem> GetMenuItemListAdmin()
        {
            return objMenuItem.GetMenuItemListAdmin();
        }

        public List<MenuItem> GetMenuItemListCustomer()
        {
            //throw new NotImplementedException();
            return objMenuItem.GetMenuItemListCustomer();
        }

        public void ModifyMenuItem(MenuItem menuItem)
        {
            objMenuItem.ModifyMenuItem(menuItem);
        }
    }
}
